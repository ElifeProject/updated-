
<?php
	include 'config/database.php';

	$database = new Database();
    $db = $database->getConnection();
    
        $Pro_id = isset($_GET['Pro_id']) ? $_GET['Pro_id']:die('ERROR: id not found');
        $query = "DELETE FROM product_details WHERE Pro_id = ?";
        $stmt = $db->prepare($query);
        $stmt->bindParam(1,$Pro_id);
        if($stmt->execute()){
            header('Location: proindex.php?action=deleted');

        }
        else{
            die('unable to delete product');
        }    
?>