<?php
if(!isset($_SESSION['cart']))
{
    $_SESSION['cart']=array();
}
 
while($row=$stmt -> fetch(PDO::FETCH_ASSOC))
    {
    extract ($row);

    echo "<div class='col-md-4 m-b-20px'>";
        echo"<div class = 'Product-id display-none'> {$Pro_id} </div>";
        echo"<a href='product.php?Pro_id = {$Pro_id}'class='product-link'>";
            $product_image->Product_id=$Pro_id;
            $stmt_product_image=$product_image->readFirst();
            //echo "$row->cat_id";
            //if form submitted
            include_once 'config/database.php';
            include_once 'object/product.php';
            include_once "object/category.php";
            $database = new Database();
            $db = $database->getConnection();
            $product = new Product($db);
            $category = new Category($db);
            $try = $product->readOne();
            //echo "$cat_id";
            //if ($cat_id==2){
            while ($row_product_image = $stmt_product_image->fetch(PDO::FETCH_ASSOC)){
                echo "<div class='m-b-10px'>";
                    echo "<img src='uploads/img/{$row_product_image['image_name']}' class='w-100-pct' />";
                echo "</div>";
            }
 
            // product name
            echo "<div class='product-name m-b-10px'>{$Pro_name}</div>";
            echo "<div class='product-name m-b-10px'>Rs " . number_format($price, 2, '.', ',') . "</div>";
        echo "</a>";
 
        // add to cart button
        echo "<div class='m-b-10px'>";
            if(array_key_exists($Pro_id, $_SESSION['cart'])){
                echo "<a href='cart.php' class='btn btn-success w-100-pct'>";
                    echo "Add to  Cart";
                echo "</a>";
            }else{
                echo "<a href='add_cart.php?Pro_id={$Pro_id}&page={$page}' class='btn btn-primary w-100-pct'>Add to Cart</a>";
            }
        echo "</div>";
    
    echo "</div>";
//}
}
 
include_once "paging.php";
?>