<?php
// start session
session_start();
include 'config/database.php';
 
// include objects
include_once "object/product.php";
include_once "object/pro_image.php";
$database = new Database();
$db = $database->getConnection();
 
// initialize objects
$product = new Product($db);
$product_image = new ProductImage($db);
// to prevent undefined index notice
$action = isset($_GET['action']) ? $_GET['action']: "";
// for pagination purposes
$page = isset($_GET['page']) ? $_GET['page'] : 1; 
$records_per_page = 6;
$from_record_num = ($records_per_page * $page) - $records_per_page;
// set page title
$page_title="Products";
$sum = 0;
$arrs = array();
$stmt = $product->countbyid();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);
        if ($cat_id== 1){
        $arrs[] = $Pro_id;
        $sum = $sum + 1;
    }
}
//echo "string";
echo "$sum";
 
// page header html
include 'layout_head.php';
 echo "<div class='col-md-12'>";
    if($action=='added'){
        echo "<div class='alert alert-info'>";
            echo "Product was added to your cart!";
        echo "</div>";
    }
 
    if($action=='exists'){
        echo "<div class='alert alert-info'>";
            echo "Product already exists in your cart!";
        echo "</div>";
    }
echo "</div>";
// read all products in the database
$stmt=$product->readdata($arrs,$from_record_num, $records_per_page);
 
// count number of retrieved products
$num = $stmt->rowCount();
 
// if products retrieved were more than zero
if($num>0){
    // needed for paging
    $page_url="computer_accessories.php?";
    $t_rows=$sum;
   // echo "$t_rows";
 
    // show products
    include_once "read_products_template.php";
}
 
// tell the user if there's no products in the database
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>No products found.</div>";
    echo "</div>";
}
// contents will be here 
 
// layout footer code
include 'layout_footer.php';
?>