<?php
class ProductImage{
 
    // database connection and table name
    private $conn;
    private $table_name = "product_images";
 
    // object properties
    public $Id;
    public $Product_id;
    public $image_name;
    public function __construct($db){
        $this->conn = $db;

    }
    function readByProductId(){
        $query = "SELECT Id, Product_id, image_name
                FROM " . $this->table_name . "
                WHERE Product_id = ?
                ORDER BY image_name ASC";
        $stmt = $this->conn->prepare( $query );
        $this->Product_id=htmlspecialchars(strip_tags($this->Product_id));
        $stmt->bindParam(1, $this->Product_id);
        $stmt->execute();
        return $stmt;
        }
    function readFirst(){
        $query = "SELECT Id, Product_id, image_name
                FROM " . $this->table_name . "
                WHERE Product_id = ?
                ORDER BY image_name ASC
                LIMIT 0, 1";
        $stmt = $this->conn->prepare( $query );
        $this->Id=htmlspecialchars(strip_tags($this->Id));
        $stmt->bindParam(1, $this->Product_id);
        $stmt->execute();
        return $stmt;
        }

    function UploadPhoto(){
            $result_message="";
            if($this->image_name){
                $target->directory = "img/";
                $target_file = $target->directory . $this->image_name;
                $file_type = pathinfo($target_file, PATHINFO_EXTENSION);

                $file_upload_error_messages=""; 
                $check = getimagesize($_FILES["image_name"]["tmp_name"]);
                if($check!=false){
                    //file is image
                }else{
                    $file_upload_error_messages.="<div>File is not an image.</div>";
                }
                $allowed_file_types=array("jpg", "jpeg", "png", "gif");

                if(!in_array($file_type, $allowed_file_types)){
                    $file_upload_error_messages.="<div>only jpg, png, jpeg, gif are allowed</div>"; 
                }
                if(file_exists($target_file)){
                    $file_upload_error_messages.="<div>already exist ,change name of file</div>";
                }
                if($_FILES['image_name']['size'] > 1024000){
                    $file_upload_error_messages.="<div>image must be less than 1MB in size</div>";
                }
                if(!is_dir($target_directory)){
                    mdir($target_directory, 0777, true);
                }
                if(empty($file_upload_error_messages)){
                    if(move_uploaded_file($_FILES["image_name"]["tmp_name"], $target_file)){
                        //image uploaded
                    }
                    else{
                        $result_message.="<div class='alert alert-danger'>";
                            $result_message.="<div>Unable to upload image</div>";
                            $result_message.="<div>unable to record upload image</div>";
                        $result_message.="</div>";
                    }
                }
                else{
                    //errro occured
                    $result_message.="<div class='alert alert-danger'>";
                            $result_message.="{$file_upload_error_message}";
                            $result_message.="<div>unable record to upload image</div>";
                        $result_message.="</div>";
                }
            }
            return $result_message;
        }

    function create(){
            $query = "INSERT INTO
                        " . $this->table_name . "SET Product_id=:Product_id, image_name=:image_name WHERE id=?";
     
            $stmt = $this->conn->prepare($query);
     
            // posted values
            $this->Product_id=htmlspecialchars(strip_tags($this->Product_id));
            $this->image_name=htmlspecialchars(strip_tags($this->image_name));
            $stmt->bindParam(1,$this->id);
           
            echo "string";
            if($stmt->execute()){
                return true;
            }else{
                return false;
            }
     
        }   
}