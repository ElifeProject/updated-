<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title><?php echo isset($page_title) ? strip_tags($page_title) : "Store Admin"; ?></title>
    <!--<title>E-Life</title>-->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <!-- <link href="<?php echo $home_url . "style.css" ?>" rel="stylesheet" />-->
    <link rel="stylesheet" href="style.css">

</head>
<body>
    
    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- ***** Navbar Area ***** -->
        <div class="alazea-main-menu">
            <div class="classy-nav-container breakpoint-off navbar navbar-default-static-top" role="navigation">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="alazeaNav">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                             </button>
                        </div>

                        <!-- Nav Brand -->
                        <a href="<?php echo $home_url; ?>admin/index.php" class="nav-brand"><img src="../img/logo.png" style="width: 100px";></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Navbar Start -->
                            <div class="classynav font-cursive">
                                <ul class="nav navbar-nav">
                                    <li <?php echo $page_title=="Admin Index" ? "class='active'":""; ?>>
                                        <a href="<?php echo $home_url; ?>admin/index.php">Home</a>
                                    </li>  
                                </ul>
                                <ul class="nav navbar-nav navbar-right">
                                    <li>
                                        <a href="#"class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expandad="false">
                                            <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                                            &nbsp;&nbsp;<?php echo $_SESSION['firstname'];?>
                                            &nbsp;&nbsp;<span class="caret"></span>
                                        </a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="<?php echo $home_url; ?>logout.php">Logout</li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <!-- Navbar End -->
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="container">
                <div class="col-md-12">
                    <div>
                        <h1><?php echo isset($page_title) ? $page_title:"The code of iqra";  ?>
                        </h1>
                    </div>
                </div>
            </div>
                    <!-- Search Form -->
                    <div class="search-form">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                            <button type="submit" class="d-none"></button>
                        </form>
                        <!-- Close Icon -->
                        <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->
        