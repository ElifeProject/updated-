<?php
// start session
session_start();
include 'config/database.php';
include_once 'object/product.php';
include_once 'object/pro_image.php';
$database=new Database();
$db=$database->getConnection();

$product= new Product($db);
$product_image= new ProductImage($db);
$action = isset($_GET['action']) ? $_GET['action']: "";
// for pagination purposes
$page= isset($_GET['page']) ? ($_GET['page']) :1; 
$records_per_page=10;
$from_record_num=($records_per_page * $page) - $records_per_page;
$page_title="Men's_Fashion";
$sum = 0;
$arrs = array();
$stmt = $product->countbyid();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);
        if ($cat_id== 6){
        $arrs[] = $Pro_id;
        $sum = $sum + 1;
    }
}
//echo "string";
//echo "$sum";
include 'layout_head.php';
 echo "<div class='col-md-12'>";
    if($action=='added'){
        echo "<div class='alert alert-info'>";
            echo "Product was added to your cart!";
        echo "</div>";
    }
    if($action=='exists'){
        echo "<div class='alert alert-info'>";
            echo "Product already exists in your cart!";
        echo "</div>";
    }
echo "</div>";
$stmt=$product->readdata($arrs,$from_record_num, $records_per_page);
$num = $stmt->rowCount();
 
// if products retrieved were more than zero
if($num>0){
    $page_url="Men's_Fashion.php?";
    $t_rows=$sum;
   // echo "$t_rows";
    include_once 'read_prod.php';
}
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>No products found.</div>";
    echo "</div>";
}
include_once 'layout_footer.php';
?>